#Loading Necessary Libraries to R from above packages.

library(tidyverse)
library(tidytext)
library(tm)
library(wordcloud)
library(lattice)
library(textdata)
library(scales)
library(syuzhet)
library(readxl)

#Loading dataset
inf6029_y2 <- read_excel("Anonymised Student Feedback - Text Comments-20230824T083146Z-001/Anonymised Student Feedback - Text Comments/AY2021-2022/Copy of INF6029 AY2021-2022.xlsx")

#Rename columns
names(inf6029_y2) <- c("Positive", "Negative")

#Slice columns
inf6029_y2_pos <- select(inf6029_y2, Positive)
inf6029_y2_neg <- select(inf6029_y2, Negative)

inf6029_y2_tidy_dataset_pos = inf6029_y2_pos %>% unnest_tokens(word, Positive)
inf6029_y2_tidy_dataset_neg = inf6029_y2_neg %>% unnest_tokens(word, Negative)

#Removing stop words from the tidy_data set
data("stop_words")

##Positive
inf6029_y2_tidy_dataset_pos2 = inf6029_y2_tidy_dataset_pos %>% anti_join(stop_words)
inf6029_y2_tidy_dataset_pos2 %>% count(word) %>% arrange(desc(n))

##Negative
inf6029_y2_tidy_dataset_neg2 = inf6029_y2_tidy_dataset_neg %>% anti_join(stop_words)
inf6029_y2_tidy_dataset_neg2 %>% count(word) %>% arrange(desc(n))

#Removing numeric variables, new lines, tabs, and spaces
patterndigits = '\\b[0-9]+\\b'

##Positive
inf6029_y2_tidy_dataset_pos2$word = inf6029_y2_tidy_dataset_pos2$word %>%
  str_replace_all(patterndigits, '')

patternewline ='\n+'

inf6029_y2_tidy_dataset_pos2$word = inf6029_y2_tidy_dataset_pos2$word %>%
  str_replace_all(patternewline, '')

inf6029_y2_tidy_dataset_pos2$word = inf6029_y2_tidy_dataset_pos2$word %>%
  str_replace_all('[:space:]', '')

inf6029_y2_tidy_dataset_pos3 = filter(inf6029_y2_tidy_dataset_pos2,!(word == ''))

##Negative
inf6029_y2_tidy_dataset_neg2$word = inf6029_y2_tidy_dataset_neg2$word %>%
  str_replace_all(patterndigits, '')

patternewline ='\n+'

inf6029_y2_tidy_dataset_neg2$word = inf6029_y2_tidy_dataset_neg2$word %>%
  str_replace_all(patternewline, '')

inf6029_y2_tidy_dataset_neg2$word = inf6029_y2_tidy_dataset_neg2$word %>%
  str_replace_all('[:space:]', '')

inf6029_y2_tidy_dataset_neg3 = filter(inf6029_y2_tidy_dataset_neg2,!(word == ''))

#Getting word frequency
inf6029_y2_tidy_dataset_pos3 %>% count(word) %>% arrange(desc(n))
inf6029_y2_tidy_dataset_neg3 %>% count(word) %>% arrange(desc(n))

#Plotting word frequency
##Positive
inf6029_y2_frequency_pos = inf6029_y2_tidy_dataset_pos3 %>% count(word) %>% arrange(desc(n))

ggplot(inf6029_y2_frequency_pos[1:5,], aes(word, n)) +
  geom_col(fill = "green") +
  scale_y_continuous(breaks = seq(0, 5, 1)) +
  labs(x = "Terms", y = "Word Frequencies", title = "INF6029: Top 5 Most Frequent Positive Words",
       subtitle = "(2021-2022)")

##Negative
inf6029_y2_frequency_neg = inf6029_y2_tidy_dataset_neg3 %>% count(word) %>% arrange(desc(n))

ggplot(inf6029_y2_frequency_neg[1:5,], aes(word, n)) +
  geom_col(fill = "purple") +
  scale_y_continuous(breaks = seq(0, 5, 1)) +
  labs(x = "Terms", y = "Word Frequencies", title = "INF6029: Top 5 Most Frequent Negative Words",
       subtitle = "(2021-2022)")

#Sentiment Analysis
##Positive
inf6029_y2_senti_pos <- get_sentences(inf6029_y2$Positive)
inf6029_y2_senti_pos_figs <- get_sentiment(inf6029_y2_senti_pos, method = 'afinn')
summary(inf6029_y2_senti_pos_figs)
sd(inf6029_y2_senti_pos_figs)

#Negative
inf6029_y2_senti_neg <- get_sentences(inf6029_y2$Negative)
inf6029_y2_senti_neg_figs <- get_sentiment(inf6029_y2_senti_neg, method = 'afinn')
summary(inf6029_y2_senti_neg_figs)
sd(inf6029_y2_senti_neg_figs)