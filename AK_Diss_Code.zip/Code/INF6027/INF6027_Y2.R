#Loading Necessary Libraries to R from above packages.

library(tidyverse)
library(tidytext)
library(tm)
library(wordcloud)
library(lattice)
library(textdata)
library(scales)
library(syuzhet)
library(readxl)

#Loading dataset
inf6027_y2 <- read_excel("Anonymised Student Feedback - Text Comments-20230824T083146Z-001/Anonymised Student Feedback - Text Comments/AY2021-2022/Copy of INF6027 AY2021-2022.xlsx")

#Rename columns
names(inf6027_y2) <- c("Positive", "Negative")

#Slice columns
inf6027_y2_pos <- select(inf6027_y2, Positive)
inf6027_y2_neg <- select(inf6027_y2, Negative)

inf6027_y2_tidy_dataset_pos = inf6027_y2_pos %>% unnest_tokens(word, Positive)
inf6027_y2_tidy_dataset_neg = inf6027_y2_neg %>% unnest_tokens(word, Negative)

#Removing stop words from the tidy_data set
data("stop_words")

##Positive
inf6027_y2_tidy_dataset_pos2 = inf6027_y2_tidy_dataset_pos %>% anti_join(stop_words)
inf6027_y2_tidy_dataset_pos2 %>% count(word) %>% arrange(desc(n))

##Negative
inf6027_y2_tidy_dataset_neg2 = inf6027_y2_tidy_dataset_neg %>% anti_join(stop_words)
inf6027_y2_tidy_dataset_neg2 %>% count(word) %>% arrange(desc(n))

#Removing numeric variables, new lines, tabs, and spaces
patterndigits = '\\b[0-9]+\\b'

##Positive
inf6027_y2_tidy_dataset_pos2$word = inf6027_y2_tidy_dataset_pos2$word %>%
  str_replace_all(patterndigits, '')

patternewline ='\n+'

inf6027_y2_tidy_dataset_pos2$word = inf6027_y2_tidy_dataset_pos2$word %>%
  str_replace_all(patternewline, '')

inf6027_y2_tidy_dataset_pos2$word = inf6027_y2_tidy_dataset_pos2$word %>%
  str_replace_all('[:space:]', '')

inf6027_y2_tidy_dataset_pos3 = filter(inf6027_y2_tidy_dataset_pos2,!(word == ''))

##Negative
inf6027_y2_tidy_dataset_neg2$word = inf6027_y2_tidy_dataset_neg2$word %>%
  str_replace_all(patterndigits, '')

patternewline ='\n+'

inf6027_y2_tidy_dataset_neg2$word = inf6027_y2_tidy_dataset_neg2$word %>%
  str_replace_all(patternewline, '')

inf6027_y2_tidy_dataset_neg2$word = inf6027_y2_tidy_dataset_neg2$word %>%
  str_replace_all('[:space:]', '')

inf6027_y2_tidy_dataset_neg3 = filter(inf6027_y2_tidy_dataset_neg2,!(word == ''))

#Getting word frequency
inf6027_y2_tidy_dataset_pos3 %>% count(word) %>% arrange(desc(n))
inf6027_y2_tidy_dataset_neg3 %>% count(word) %>% arrange(desc(n))

#Plotting word frequency
##Positive
inf6027_y2_frequency_pos = inf6027_y2_tidy_dataset_pos3 %>% count(word) %>% arrange(desc(n))
inf6027_y2_frequency_pos_plot = inf6027_y2_frequency_pos[1:5,]

ggplot(inf6027_y2_frequency_pos_plot, aes(word, n)) +
  geom_col(fill = "blue") +
  scale_y_continuous(breaks = seq(0, 12, 1)) +
  labs(x = "Terms", y = "Word Frequencies", title = "INF6027: Top 5 Most Frequent Positive Words",
       subtitle = "(2021-2022)")

##Negative
inf6027_y2_frequency_neg = inf6027_y2_tidy_dataset_neg3 %>% count(word) %>% arrange(desc(n))
inf6027_y2_frequency_neg_plot = inf6027_y2_frequency_neg[1:5,]

ggplot(inf6027_y2_frequency_neg_plot, aes(word, n)) +
  geom_col(fill = "red") +
  scale_y_continuous(breaks = seq(0, 13, 1)) +
  labs(x = "Terms", y = "Word Frequencies", title = "INF6027: Top 5 Most Frequent Negative Words",
       subtitle = "(2021-2022)")

#Sentiment Analysis
##Positive
inf6027_y2_senti_pos <- get_sentences(inf6027_y2$Positive)
inf6027_y2_senti_pos_figs <- get_sentiment(inf6027_y2_senti_pos, method = 'afinn')
summary(inf6027_y2_senti_pos_figs)
sd(inf6027_y2_senti_pos_figs)

##Negative
inf6027_y2_senti_neg <- get_sentences(inf6027_y2$Negative)
inf6027_y2_senti_neg_figs <- get_sentiment(inf6027_y2_senti_neg, method = 'afinn')
summary(inf6027_y2_senti_neg_figs)
sd(inf6027_y2_senti_neg_figs)